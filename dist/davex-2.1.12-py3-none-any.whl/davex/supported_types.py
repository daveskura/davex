"""
  Dave Skura

"""
from enum import Enum

class dbtype(Enum):
	nodb		= 0
	Postgres= 1
	MySQL		= 2
	SQLite	= 3
